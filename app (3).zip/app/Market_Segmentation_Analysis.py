# -*- coding: utf-8 -*-
"""
Created on Sat Nov 11 17:52:24 2023

@author: Admin
"""


from flask import Flask,render_template,request,jsonify
import pickle
#import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
model=pickle.load(open('predictor.pkl','rb'))
encoder = pickle.load(open('encoder.pkl','rb'))
scaler = pickle.load(open('scaler.pkl','rb'))
#scalar=pickle.load(open('scaler.pkl','rb'))

app= Flask(__name__,template_folder = 'templates')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST']) # prediction route
def enter_values():
    if request.method == 'POST':
        ym = request.form.get["yummy"]
        cn = request.form.get["convenient"]
        sp = request.form.get["spicy"]
        ft = request.form.get["fattening"]
        gr = request.form.get["greasy"]
        fs = request.form.get["fast"]
        ch = request.form.get["cheap"]
        ts = request.form.get["tasty"]
        ex = request.form.get["expensive"]
        he = request.form.get["healthy"]
        ds = request.form.get["disgusting"]
        a = request.form.get["Age"]
        lk = request.form.get["Like"]
        vf = request.form.get["VisitFrequency"]
        g = request.form.get["Gender"]
        
        ym = ym.replace(['Yes','No'],[1,0])
        cn = cn.replace(['Yes','No'],[1,0])
        sp = sp.replace(['Yes','No'],[1,0])
        ft = ft.replace(['Yes','No'],[1,0])
        gr = gr.replace(['Yes','No'],[1,0])
        fs = fs.replace(['Yes','No'],[1,0])
        ch = ch.replace(['Yes','No'],[1,0])
        ts = ts.replace(['Yes','No'],[1,0])
        ex = ex.replace(['Yes','No'],[1,0])
        he = he.replace(['Yes','No'],[1,0])
        ds = ds.replace(['Yes','No'],[1,0])
        g = g.replace(['Male','Female'],[1,0])
        vf = vf.replace(['Never','Once a year','Every three months','Once a month',
                                                     'Once a week','More than once a week'],[0,1,2,3,4,5])
        lk = lk.replace(['I hate it!-5','-4','-3','-2','-1','0','+1','+2','+3','+4','I love it!+5'],
                                [0,1,2,3,4,5,6,7,8,9,10])
    
    
    
        total = [[ym,cn,sp,fl,gr,fs,ch,ts,ex,he,ds,a,vf,g]]
        total = np.array(total)
    
        prediction = model.predict(scaler.transform(total))
        output = int(prediction[0])
    
        return render_template('index.html',predict='Predicts Customer Belongs to Cluster {}'.format(output))
    
    
@app.route("/submit",methods=['POST','GET'])
def predict():
    x = [[x for x in request.form.values()]]
    print(x)
    
    x = np.array(x)
    print(x.shape)
    
    print(x)
    pred = model.predict(x)
    print(pred[0])
    return render_template('submit.html',prediction_string = str(pred))


def predict_api():
    data = request.get_json(force=True)
    prediction = model.predict(scaler.transform([total]))   
    output = int(prediction[0])
    return jsonify(output)

if __name__ == "__main__":
    app.run(debug = True)